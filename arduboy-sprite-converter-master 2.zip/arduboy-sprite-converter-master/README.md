# arduboy-sprite-converter
converts a sprite sheet to the arduboy format 
