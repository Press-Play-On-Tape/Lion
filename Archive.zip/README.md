# arduboy-image-converter
Converts a black/white image with a maximum size of 128x64 pixels as a png, jpg or gif to the arduboy format

You can use this page immediately from github pages at https://teamarg.github.io/arduboy-image-converter/
